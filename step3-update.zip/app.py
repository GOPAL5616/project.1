import os
import sqlite3
import uuid
from functools import wraps
from flask import (Flask, render_template, request, redirect, url_for,
                   session, flash, g, abort, send_from_directory)
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE_DIR, "database.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
app.secret_key = "change-this-to-any-long-random-text"
app.config["MAX_CONTENT_LENGTH"] = 60 * 1024 * 1024  # 60 MB per request

ALLOWED_IMAGES = {"jpg", "jpeg", "png", "gif", "webp"}
ALLOWED_VIDEOS = {"mp4", "webm", "mov"}
MAX_IMAGES = 4
MAX_IMAGE_MB = 5
MAX_VIDEO_MB = 30

DEPARTMENTS = ["Computer Science", "Information Technology", "Mechanical",
               "Civil", "Electrical", "Electronics", "Management"]

# problem type, kaun handle karega
PROBLEM_TYPES = [("Class", "hod"), ("College", "admin"), ("Bus", "admin"),
                 ("Canteen", "admin"), ("Library", "admin"),
                 ("Mess", "admin"), ("Hostel", "admin")]


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB)
    db.executescript("""
    CREATE TABLE IF NOT EXISTS departments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL
    );
    CREATE TABLE IF NOT EXISTS problem_types (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        handled_by TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'student',
        department_id INTEGER,
        is_active INTEGER NOT NULL DEFAULT 1,
        must_change_password INTEGER NOT NULL DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (department_id) REFERENCES departments(id)
    );
    CREATE TABLE IF NOT EXISTS problems (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        problem_code TEXT UNIQUE,
        user_id INTEGER NOT NULL,
        type_id INTEGER NOT NULL,
        department_id INTEGER,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        visibility TEXT NOT NULL DEFAULT 'public',
        anonymous INTEGER NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'Pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (type_id) REFERENCES problem_types(id),
        FOREIGN KEY (department_id) REFERENCES departments(id)
    );
    CREATE TABLE IF NOT EXISTS problem_media (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        problem_id INTEGER NOT NULL,
        filename TEXT NOT NULL,
        media_type TEXT NOT NULL,
        FOREIGN KEY (problem_id) REFERENCES problems(id)
    );
    CREATE TABLE IF NOT EXISTS problem_likes (
        problem_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (problem_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS problem_relatable (
        problem_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (problem_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        problem_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        body TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (problem_id) REFERENCES problems(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    """)
    for d in DEPARTMENTS:
        db.execute("INSERT OR IGNORE INTO departments(name) VALUES (?)", (d,))
    for name, handler in PROBLEM_TYPES:
        db.execute("INSERT OR IGNORE INTO problem_types(name, handled_by) VALUES (?, ?)",
                   (name, handler))
    db.commit()
    db.close()


# ----------------------------------------------------------- access control
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        uid = session.get("user_id")
        user = None
        if uid:
            user = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
        if not user or not user["is_active"]:
            session.clear()
            flash("Please log in first.", "bad")
            return redirect(url_for("login"))
        g.user = user
        session["role"] = user["role"]
        return f(*args, **kwargs)
    return wrapper


def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if g.user["role"] not in roles:
                flash("You do not have permission to open that page.", "bad")
                return redirect(url_for("home"))
            return f(*args, **kwargs)
        return wrapper
    return decorator


def can_view(p, user):
    """Who can see a problem (and its photos/videos)."""
    if p["user_id"] == user["id"]:
        return True
    if p["visibility"] == "public":
        return True
    role = user["role"]
    if role in ("superadmin", "admin", "faculty"):
        return True
    if role == "hod":
        return (p["department_id"] is not None
                and p["department_id"] == user["department_id"])
    return False


# ------------------------------------------------------------------ helpers
PROBLEM_SELECT = """
SELECT p.*, t.name AS type_name, u.name AS author_name, d.name AS dept_name,
  (SELECT m.id FROM problem_media m
     WHERE m.problem_id = p.id AND m.media_type = 'image'
     ORDER BY m.id LIMIT 1) AS thumb_id,
  (SELECT COUNT(*) FROM problem_media m WHERE m.problem_id = p.id) AS media_count,
  (SELECT COUNT(*) FROM problem_likes l WHERE l.problem_id = p.id) AS like_count,
  (SELECT COUNT(*) FROM problem_relatable r WHERE r.problem_id = p.id) AS relatable_count,
  (SELECT COUNT(*) FROM comments c WHERE c.problem_id = p.id) AS comment_count
FROM problems p
JOIN problem_types t ON t.id = p.type_id
JOIN users u ON u.id = p.user_id
LEFT JOIN departments d ON d.id = p.department_id
"""


def decorate(rows, user):
    out = []
    for r in rows:
        p = dict(r)
        real_name_visible = (not p["anonymous"]) or p["user_id"] == user["id"] \
            or user["role"] == "superadmin"
        if real_name_visible:
            p["author"] = p["author_name"] + (" (anonymous post)" if p["anonymous"] else "")
        else:
            p["author"] = "Anonymous"
        out.append(p)
    return out


def file_ext(f):
    name = f.filename or ""
    return name.rsplit(".", 1)[-1].lower() if "." in name else ""


def file_size(f):
    f.stream.seek(0, os.SEEK_END)
    size = f.stream.tell()
    f.stream.seek(0)
    return size


def save_upload(f, problem_id, media_type):
    name = uuid.uuid4().hex + "." + file_ext(f)
    f.save(os.path.join(UPLOAD_FOLDER, name))
    get_db().execute(
        "INSERT INTO problem_media (problem_id, filename, media_type) VALUES (?, ?, ?)",
        (problem_id, name, media_type))


# ------------------------------------------------------------------- routes
@app.route("/")
def index():
    return redirect(url_for("home" if "user_id" in session else "login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    db = get_db()
    departments = db.execute("SELECT * FROM departments ORDER BY name").fetchall()

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        dept_id = request.form.get("department", "")

        error = None
        if not name:
            error = "Enter your full name."
        elif not email.endswith("@gmail.com") or len(email) < 12:
            error = "Only a Gmail address (@gmail.com) is allowed."
        elif not dept_id:
            error = "Select your department."
        elif len(password) < 6:
            error = "Password must be at least 6 characters."
        elif password != confirm:
            error = "Passwords do not match."
        elif db.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
            error = "This email is already registered. Please log in."

        if error:
            flash(error, "bad")
            return render_template("register.html", departments=departments)

        db.execute(
            "INSERT INTO users (name, email, password_hash, role, department_id) "
            "VALUES (?, ?, ?, 'student', ?)",
            (name, email, generate_password_hash(password), dept_id))
        db.commit()
        flash("Account created. You can log in now.", "good")
        return redirect(url_for("login"))

    return render_template("register.html", departments=departments)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()

        if not user or not check_password_hash(user["password_hash"], password):
            flash("Email or password is incorrect.", "bad")
        elif not user["is_active"]:
            flash("This account is deactivated. Contact the admin.", "bad")
        else:
            session.clear()
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["role"] = user["role"]
            return redirect(url_for("home"))
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "good")
    return redirect(url_for("login"))


@app.route("/home")
@login_required
def home():
    return render_template("home.html")


@app.route("/post", methods=["GET", "POST"])
@login_required
@role_required("student")
def post_problem():
    db = get_db()
    types = db.execute("SELECT * FROM problem_types ORDER BY id").fetchall()

    if request.method == "POST":
        type_id = request.form.get("type_id", "")
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        visibility = request.form.get("visibility", "public")
        anonymous = 1 if request.form.get("anonymous") else 0

        images = [f for f in request.files.getlist("images") if f and f.filename]
        video = request.files.get("video")
        if video is not None and not video.filename:
            video = None

        error = None
        if not db.execute("SELECT 1 FROM problem_types WHERE id = ?", (type_id,)).fetchone():
            error = "Select a problem type."
        elif not (5 <= len(title) <= 100):
            error = "Title must be 5 to 100 characters."
        elif not (20 <= len(description) <= 1000):
            error = "Describe the problem in 20 to 1000 characters."
        elif visibility not in ("public", "private"):
            error = "Choose Public or Private."
        elif len(images) > MAX_IMAGES:
            error = f"You can upload at most {MAX_IMAGES} photos."
        else:
            for f in images:
                if file_ext(f) not in ALLOWED_IMAGES:
                    error = "Photos must be JPG, PNG, GIF or WEBP."
                    break
                if file_size(f) > MAX_IMAGE_MB * 1024 * 1024:
                    error = f"Each photo must be under {MAX_IMAGE_MB} MB."
                    break
            if not error and video is not None:
                if file_ext(video) not in ALLOWED_VIDEOS:
                    error = "Video must be MP4, WEBM or MOV."
                elif file_size(video) > MAX_VIDEO_MB * 1024 * 1024:
                    error = f"Video must be under {MAX_VIDEO_MB} MB."

        if error:
            flash(error, "bad")
            return render_template("post.html", types=types, form=request.form,
                                   max_images=MAX_IMAGES, max_image_mb=MAX_IMAGE_MB,
                                   max_video_mb=MAX_VIDEO_MB)

        cur = db.execute(
            "INSERT INTO problems (user_id, type_id, department_id, title, description, "
            "visibility, anonymous) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (g.user["id"], type_id, g.user["department_id"], title, description,
             visibility, anonymous))
        pid = cur.lastrowid
        code = f"PRB-{1000 + pid}"
        db.execute("UPDATE problems SET problem_code = ? WHERE id = ?", (code, pid))
        for f in images:
            save_upload(f, pid, "image")
        if video is not None:
            save_upload(video, pid, "video")
        db.commit()

        flash(f"Problem posted. Your Problem ID is {code}.", "good")
        return redirect(url_for("problem_detail", code=code))

    return render_template("post.html", types=types, form={},
                           max_images=MAX_IMAGES, max_image_mb=MAX_IMAGE_MB,
                           max_video_mb=MAX_VIDEO_MB)


@app.route("/feed")
@login_required
def feed():
    db = get_db()
    types = db.execute("SELECT * FROM problem_types ORDER BY id").fetchall()
    selected = request.args.get("type", "").strip()

    sql = PROBLEM_SELECT + " WHERE p.visibility = 'public'"
    params = []
    if selected:
        sql += " AND t.name = ?"
        params.append(selected)
    sql += " ORDER BY p.id DESC LIMIT 100"

    problems = decorate(db.execute(sql, params).fetchall(), g.user)
    return render_template("feed.html", problems=problems, types=types, selected=selected)


@app.route("/my-problems")
@login_required
@role_required("student")
def my_problems():
    rows = get_db().execute(
        PROBLEM_SELECT + " WHERE p.user_id = ? ORDER BY p.id DESC", (g.user["id"],)).fetchall()
    return render_template("my_problems.html", problems=decorate(rows, g.user))


def get_visible_problem(code):
    row = get_db().execute(PROBLEM_SELECT + " WHERE p.problem_code = ?", (code,)).fetchone()
    if row is None or not can_view(row, g.user):
        abort(404)
    return row


@app.route("/problem/<code>")
@login_required
def problem_detail(code):
    db = get_db()
    row = get_visible_problem(code)
    p = decorate([row], g.user)[0]
    media = db.execute(
        "SELECT * FROM problem_media WHERE problem_id = ? ORDER BY id", (row["id"],)).fetchall()
    uid = g.user["id"]
    liked = db.execute("SELECT 1 FROM problem_likes WHERE problem_id = ? AND user_id = ?",
                       (row["id"], uid)).fetchone() is not None
    relatable = db.execute("SELECT 1 FROM problem_relatable WHERE problem_id = ? AND user_id = ?",
                           (row["id"], uid)).fetchone() is not None

    comments = []
    for c in db.execute(
            "SELECT c.*, u.name AS user_name, u.role AS user_role FROM comments c "
            "JOIN users u ON u.id = c.user_id WHERE c.problem_id = ? ORDER BY c.id",
            (row["id"],)).fetchall():
        c = dict(c)
        is_owner = c["user_id"] == row["user_id"]
        if is_owner and row["anonymous"] and uid != row["user_id"] \
                and g.user["role"] != "superadmin":
            c["who"] = "Anonymous (post author)"
        else:
            c["who"] = c["user_name"] + (" (post author)" if is_owner else "")
        c["staff"] = c["user_role"] != "student"
        comments.append(c)

    return render_template("problem.html", p=p, media=media, liked=liked,
                           relatable=relatable, comments=comments)


def toggle_reaction(table, code):
    db = get_db()
    row = get_visible_problem(code)
    uid = g.user["id"]
    exists = db.execute(f"SELECT 1 FROM {table} WHERE problem_id = ? AND user_id = ?",
                        (row["id"], uid)).fetchone()
    if exists:
        db.execute(f"DELETE FROM {table} WHERE problem_id = ? AND user_id = ?", (row["id"], uid))
    else:
        db.execute(f"INSERT INTO {table} (problem_id, user_id) VALUES (?, ?)", (row["id"], uid))
    db.commit()
    return redirect(url_for("problem_detail", code=code) + "#react")


@app.route("/problem/<code>/like", methods=["POST"])
@login_required
def like_problem(code):
    return toggle_reaction("problem_likes", code)


@app.route("/problem/<code>/relatable", methods=["POST"])
@login_required
def relatable_problem(code):
    return toggle_reaction("problem_relatable", code)


@app.route("/problem/<code>/comment", methods=["POST"])
@login_required
def add_comment(code):
    row = get_visible_problem(code)
    body = request.form.get("body", "").strip()
    if not (1 <= len(body) <= 500):
        flash("Comment must be 1 to 500 characters.", "bad")
    else:
        db = get_db()
        db.execute("INSERT INTO comments (problem_id, user_id, body) VALUES (?, ?, ?)",
                   (row["id"], g.user["id"], body))
        db.commit()
    return redirect(url_for("problem_detail", code=code) + "#comments")


@app.route("/media/<int:media_id>")
@login_required
def media(media_id):
    m = get_db().execute(
        "SELECT m.*, p.user_id, p.visibility, p.department_id "
        "FROM problem_media m JOIN problems p ON p.id = m.problem_id WHERE m.id = ?",
        (media_id,)).fetchone()
    if m is None or not can_view(m, g.user):
        abort(404)
    return send_from_directory(UPLOAD_FOLDER, m["filename"])


# ----------------------------------------------------------- error handlers
@app.errorhandler(404)
def not_found(e):
    return ("<p style='font-family:sans-serif;padding:24px'>Page not found or you do not "
            "have access. <a href='/'>Go home</a></p>"), 404


@app.errorhandler(413)
def too_large(e):
    flash(f"Upload too large. Photos max {MAX_IMAGE_MB} MB each, video max {MAX_VIDEO_MB} MB.",
          "bad")
    return redirect(url_for("post_problem"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)

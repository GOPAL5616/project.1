# Gmail details used to send the verification code (OTP) to students.
# Fill these two lines, save, and restart the server (python app.py).
#
# EMAIL_ADDRESS      : the Gmail that will SEND the codes (make a new Gmail for the project)
# EMAIL_APP_PASSWORD : a 16-letter Google "App password" (NOT the normal Gmail password)
#
# While both are empty, the site runs in TEST MODE and prints the code in the terminal.

EMAIL_ADDRESS = ""
EMAIL_APP_PASSWORD = ""
